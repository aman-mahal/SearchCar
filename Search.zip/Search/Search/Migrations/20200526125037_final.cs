﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Search.Migrations
{
    public partial class final : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Cars",
                columns: new[] { "Car_Id", "BrandModelsModel_Id", "Color", "Description", "Model_Id", "Price", "Year" },
                values: new object[,]
                {
                    { 10, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 25, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 24, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 23, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 22, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 21, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 20, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 19, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 18, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 17, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 16, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 15, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 14, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 13, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 12, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 11, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 26, null, "Black", "describe the product here", 1, "1 crore", 2018 },
                    { 27, null, "Black", "describe the product here", 1, "1 crore", 2018 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "Cars",
                keyColumn: "Car_Id",
                keyValue: 27);
        }
    }
}
