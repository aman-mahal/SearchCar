import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { CarsService } from "../services/cars.service";
import { Details } from "../models/Details";
@Component({
  selector: "app-form",
  templateUrl: "./form.component.html",
  styleUrls: ["./form.component.css"],
})
export class FormComponent implements OnInit {
  Brands$: Observable<Details[]>;
  brand_id: number;
  model_id: number;
  color: string;
  year: string;
  brands = new Details();
  brndArr: any;
  modelsArr: any;
  carArr: any;
  totalRecords: number;
  page: number = 1;
  title = "angulardatatables";
  // dtOptions: DataTables.Settings = {};
  constructor(private carsService: CarsService) {}

  ngOnInit() {
    this.loadBrands();
  }
  loadBrands() {
    this.carsService.getBrands().subscribe((res) => {
      this.brndArr = res;
    });
    // console.log(this.Brands$);
  }
  loadModels(event) {
    this.brand_id = event.target.value;
    this.carsService.getModels(this.brand_id).subscribe((res) => {
      this.modelsArr = res.models;
    });
    // console.log(event.target.value);
  }
  onSubmit() {
    this.brand_id = this.brands.brand_Id;
    this.model_id = this.brands.model_Id;
    this.color = this.brands.color;
    this.year = this.brands.year;
    this.carsService
      .getCar(this.brand_id, this.model_id, this.color, this.year)
      .subscribe((res) => {
        this.carArr = res;
        this.totalRecords = this.carArr.length;
        console.log(this.totalRecords)
        //console.log(this.brands.brand_Id);
        // this.dtOptions = {
        //   pagingType: "full_numbers",
        //   pageLength: 5,
        //   processing: true,
        // };
      });
    ;
  }
}
