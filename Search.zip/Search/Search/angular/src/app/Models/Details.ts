export class Details {
  brand_Id: any = "";
  model_Id: any = "";
  brand_Name: any = "";
  models: any = "";
  color?: any = "";
  year?: any = "";
}
