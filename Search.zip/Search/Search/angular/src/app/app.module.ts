import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from "./app-routing.module";
import { DataTablesModule } from "angular-datatables";
import { AppComponent } from "./app.component";
import { NavbarComponent } from "./navbar/navbar.component";
import { CarsService } from "./services/cars.service";
import { FormComponent } from "./form/form.component";
import { OutputComponent } from "./output/output.component";
import { FormsModule } from "@angular/forms";
import { NgxPaginationModule } from "ngx-pagination";

@NgModule({
  declarations: [AppComponent, NavbarComponent, FormComponent, OutputComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    DataTablesModule,
    NgxPaginationModule,
  ],
  providers: [CarsService],
  bootstrap: [AppComponent],
})
export class AppModule {}
