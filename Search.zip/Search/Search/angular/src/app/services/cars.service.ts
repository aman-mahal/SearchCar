import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { retry, catchError } from "rxjs/operators";
import { environment } from "src/environments/environment";
import { Details } from "../models/Details";
@Injectable({
  providedIn: "root",
})
export class CarsService {
  myAppUrl: string;
  myApiUrl: string;
  myApiUrl1: string;
  httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json; charset=utf-8",
    }),
  };

  constructor(private http: HttpClient) {
    this.myAppUrl = environment.appUrl;
    this.myApiUrl = "api/brands/";
    this.myApiUrl1 = "api/ModelCars/";
  }

  getBrands(): Observable<Details[]> {
    return this.http
      .get<Details[]>(this.myAppUrl + this.myApiUrl)
      .pipe(retry(1), catchError(this.errorHandler));
  }

  getModels(brand_id: number): Observable<Details> {
    return this.http
      .get<Details>(this.myAppUrl + this.myApiUrl + brand_id)
      .pipe(retry(1), catchError(this.errorHandler));
  }

  getCar(
    brand_id: number,
    model_id: number,
    color: string,
    year: string
  ): Observable<Details> {
    return this.http
      .get<Details>(
        this.myAppUrl +
          this.myApiUrl1 +
          "?brandId=" +
          brand_id +
          "&&modelId=" +
          model_id +
          "&&color=" +
          color +
          "&&year=" +
          year
      )
      .pipe(retry(1), catchError(this.errorHandler));
  }

  errorHandler(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
