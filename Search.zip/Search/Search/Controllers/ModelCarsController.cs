﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Search.Models;
using Microsoft.Data.SqlClient;

namespace Search.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModelCarsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ModelCarsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/ModelCars
        [HttpGet]
        //public async Task<ActionResult<IEnumerable<ModelCars>>> GetCars()
        //{
        //    return await _context.Cars.ToListAsync();
        //}

        public IActionResult GetCars(string brandId, string modelId,string color, string year)
        {

            String constring = "Server=(LocalDb)\\MSSQLLocalDB;Database=cars;Trusted_Connection=True;MultipleActiveResultSets=True";
            SqlConnection sqlconn = new SqlConnection(constring);
            String pname = "CarsSearch";
            sqlconn.Open();
            SqlCommand comm = new SqlCommand(pname, sqlconn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@year",Convert.ToInt32(year));
            comm.Parameters.AddWithValue("@brand_id", Convert.ToInt32(brandId));
            comm.Parameters.AddWithValue("@model_id", Convert.ToInt32(modelId));
            comm.Parameters.AddWithValue("@color", color);
            SqlDataReader dr = comm.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            return Ok(dt);





        }

        // GET: api/ModelCars/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ModelCars>> GetModelCars(int id)
        {
            var modelCars = await _context.Cars.FindAsync(id);

            if (modelCars == null)
            {
                return NotFound();
            }

            return modelCars;
        }

        // PUT: api/ModelCars/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutModelCars(int id, ModelCars modelCars)
        {
            if (id != modelCars.Model_Id)
            {
                return BadRequest();
            }

            _context.Entry(modelCars).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ModelCarsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ModelCars
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ModelCars>> PostModelCars(ModelCars modelCars)
        {
            _context.Cars.Add(modelCars);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetModelCars", new { id = modelCars.Model_Id }, modelCars);
        }

        // DELETE: api/ModelCars/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ModelCars>> DeleteModelCars(int id)
        {
            var modelCars = await _context.Cars.FindAsync(id);
            if (modelCars == null)
            {
                return NotFound();
            }

            _context.Cars.Remove(modelCars);
            await _context.SaveChangesAsync();

            return modelCars;
        }

        private bool ModelCarsExists(int id)
        {
            return _context.Cars.Any(e => e.Model_Id == id);
        }
    }
}
