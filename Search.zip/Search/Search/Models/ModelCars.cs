﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Search.Models
{
    public class ModelCars
    {
        [Key]
        public int Car_Id { get; set; }
        public int Model_Id { get; set; }


        //public string Car_Model_Name { get; set; }

        public string Color { get; set; }

        public int Year { get; set; }

        public string Price { get; set; }

        public string Description { get; set; }
    }
}
