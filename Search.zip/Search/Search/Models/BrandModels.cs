﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Search.Models
{
    public class BrandModels
    {
        
        public int Brand_Id { get; set; }

        [Key]
        public int Model_Id { get; set; }

        public string Model_Name { get; set; }

        public List<ModelCars> Cars { get; set; }
    }
}
