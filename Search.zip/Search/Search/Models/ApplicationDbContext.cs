﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Search.Models
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Brand> Brands { get; set; }

        public DbSet<BrandModels> Models { get; set; }

        public DbSet<ModelCars>Cars { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(" Server = (localdb)\\mssqllocaldb; Database =cars; Trusted_Connection = True; MultipleActiveResultSets = true");
            }

            optionsBuilder.EnableSensitiveDataLogging();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //seed categories
            modelBuilder.Entity<Brand>().HasData(new Brand { Brand_Id = 1, Brand_Name = "Lamborghini" });
            modelBuilder.Entity<Brand>().HasData(new Brand { Brand_Id = 2, Brand_Name = "Porsche" });
            modelBuilder.Entity<Brand>().HasData(new Brand { Brand_Id = 3, Brand_Name = "Ferrari" });
            modelBuilder.Entity<Brand>().HasData(new Brand { Brand_Id = 4, Brand_Name = "Ford" });
            modelBuilder.Entity<Brand>().HasData(new Brand { Brand_Id = 5, Brand_Name = "Audi" });


            //seed products

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 1,
                Model_Id=1,
                Model_Name = "Avantador"
                
                
            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 1,
                Model_Id = 2,
                Model_Name = "Huracan"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 1,
                Model_Id = 3,
                Model_Name = "Urus"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 1,
                Model_Id = 4,
                Model_Name = "Centenario"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 1,
                Model_Id = 5,
                Model_Name = "Sian"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 2,
                Model_Id = 6,
                Model_Name = "Porsche 911"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 2,
                Model_Id = 7,
                Model_Name = "Porsche Macan"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 2,
                Model_Id = 8,
                Model_Name = "Porsche 718"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 2,
                Model_Id = 9,
                Model_Name = "Porsche 918"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 2,
                Model_Id = 10,
                Model_Name = "Porsche Carerra"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 3,
                Model_Id = 11,
                Model_Name = "Ferrari 488"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 3,
                Model_Id = 12,
                Model_Name = "Ferrari GTC4Luso"
               

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 3,
                Model_Id = 13,
                Model_Name = "Ferrari Portfino"
               

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 3,
                Model_Id = 14,
                Model_Name = "Ferrari 818"
               

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 3,
                Model_Id = 15,
                Model_Name = "Ferrari 818 Superfast"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 4,
                Model_Id = 16,
                Model_Name = "Ford Ecosport"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 4,
                Model_Id = 17,
                Model_Name = "Ford Endevaour"
               

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 4,
                Model_Id = 18,
                Model_Name = "Ford FreeStyle"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 4,
                Model_Id = 19,
                Model_Name = "Ford Mustang"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 4,
                Model_Id = 20,
                Model_Name = "Ford Figo"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 5,
                Model_Id = 21,
                Model_Name = "Audi A18"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 5,
                Model_Id = 22,
                Model_Name = "Audi A5"
               

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 5,
                Model_Id = 23,
                Model_Name = "Audi Q8"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 5,
                Model_Id = 24,
                Model_Name = "Audi RS5"
                

            });

            modelBuilder.Entity<BrandModels>().HasData(new BrandModels
            {
                Brand_Id = 5,
                Model_Id = 25,
                Model_Name = "Audi S5"
               

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id=1,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 2,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2019,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 3,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2020,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 4,
                Model_Id = 1,
                Color = "White",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 5,
                Model_Id = 1,
                Color = "White",
                Price = "1 crore",
                Year = 2019,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 6,
                Model_Id = 1,
                Color = "White",
                Price = "1 crore",
                Year = 2020,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 7,
                Model_Id = 1,
                Color = "Red",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 8,
                Model_Id = 1,
                Color = "Red",
                Price = "1 crore",
                Year = 2019,
                Description = "describe the product here"

            });

            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 9,
                Model_Id = 1,
                Color = "Red",
                Price = "1 crore",
                Year = 2020,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 10,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 11,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 12,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 13,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 14,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });  
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
                 {
                     Car_Id = 15,
                     Model_Id = 1,
                     Color = "Black",
                     Price = "1 crore",
                     Year = 2018,
                     Description = "describe the product here"

                 });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 16,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 17,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 18,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 19,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 20,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 21,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 22,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 23,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 24,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 25,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 26,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
            modelBuilder.Entity<ModelCars>().HasData(new ModelCars
            {
                Car_Id = 27,
                Model_Id = 1,
                Color = "Black",
                Price = "1 crore",
                Year = 2018,
                Description = "describe the product here"

            });
        }
    }
}
